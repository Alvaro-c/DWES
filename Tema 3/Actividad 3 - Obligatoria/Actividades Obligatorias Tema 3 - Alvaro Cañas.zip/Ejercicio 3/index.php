<?php

session_start();

?>

<h1> Página principal </h1><br>

<a href="nombre-1.php">Escribir su nombre </a><br>
<a href="apellidos-1.php">Escribir sus apellidos </a><br>
<a href="ver.php">Ver su nombre y apellidos</a><br>
<a href="borrar.php">Borrar la información</a><br>