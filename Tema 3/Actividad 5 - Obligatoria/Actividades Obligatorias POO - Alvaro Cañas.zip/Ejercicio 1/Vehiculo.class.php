<?php 

class Vehiculo {

    private $color;
    private $peso;

    public function Circula() {
        // TODO
    }

    public function anadir_persona($peso_persona) {
        // TODO
    }


}