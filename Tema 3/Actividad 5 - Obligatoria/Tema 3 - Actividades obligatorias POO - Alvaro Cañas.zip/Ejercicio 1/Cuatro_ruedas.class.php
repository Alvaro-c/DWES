<?php

// Clase cuatro_ruedas
class Cuatro_ruedas extends Vehiculo {

    private $numero_puertas;

    // Método que aún no se utiliza, implementado más adelante
    public function repintar($color) {
        // TODO
    }
}