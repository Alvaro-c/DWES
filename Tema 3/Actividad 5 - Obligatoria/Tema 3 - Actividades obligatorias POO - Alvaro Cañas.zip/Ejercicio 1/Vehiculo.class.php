<?php

// Clase Vehiculo
class Vehiculo
{

    private $color;
    private $peso;

    // Método que aún no se utiliza, implementado más adelante
    public function Circula() {
        // TODO
    }

    // Método que aún no se utiliza, implementado más adelante
    public function anadir_persona($peso_persona) {
        // TODO
    }


}