<?php
	echo "Usuario introducido: " . $_POST['usuario']. "<br>";
	echo "Clave introducida: " . $_POST['clave'];