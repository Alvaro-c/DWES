<?php

namespace Foo\Bar\subespacio_de_nombres;

const FOO = 1;
function foo()
{
}
class foo
{
    static function método_estático()
    {
    }
}
