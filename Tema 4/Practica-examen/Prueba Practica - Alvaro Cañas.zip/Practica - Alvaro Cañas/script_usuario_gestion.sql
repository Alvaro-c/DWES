use pedidos;

INSERT INTO pedidos.restaurantes (Correo, Clave, Pais, CP, Ciudad, Direccion, Rol)
VALUES ('gestion', '1234', 'España', 40003, 'Segovia', 'Calle 1234', 2);