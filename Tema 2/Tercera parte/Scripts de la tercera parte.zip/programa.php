<?php
    print "Módulo $modulo del ciclo $ciclo<br />"; //Solo muestra "Modulo del ciclo"
    include 'definiciones.inc.php';
    print " Módulo $modulo del ciclo $ciclo<br />"; // muestra "Modulo DWES del ciclo DAW"
?>