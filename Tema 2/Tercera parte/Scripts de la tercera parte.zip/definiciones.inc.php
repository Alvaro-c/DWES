<?php
    $modulo = 'DWES';
    $ciclo = 'DAW';
?>