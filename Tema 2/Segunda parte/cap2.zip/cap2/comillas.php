<HTML> 
  <HEAD>
    <TITLE>Variables con Cadenas de caracteres</TITLE>
  </HEAD>
  <BODY>
    <CENTER>
    <H2>Trabajando con Cadenas de caracteres</H2> 
    <?php
    $lenguaje="PHP";
    $ver="v8";
    echo "<B>Estamos trabajando con $lenguaje ($ver) </B><BR><BR>";
    echo 'La variable $lenguaje contiene: ';
    echo $lenguaje;
    echo "<BR>";
    echo 'La variable $ver contiene: ';
    echo $ver;
    ?>
    </CENTER>
  </BODY>
</HTML>