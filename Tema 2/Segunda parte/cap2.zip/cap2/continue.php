<?php
	for($i = 0; $i < 5; $i = $i + 1){
		if ($i == 3){
			continue;
		}
		echo "$i <br>";
	}