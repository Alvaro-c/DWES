<?php
	$i = 0;
	do{
		echo "$i <br>";
		$i = $i +1;
	}while ($i < 5);